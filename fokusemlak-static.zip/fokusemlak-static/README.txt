FOKUS EMLAK - Statik Site Paketi
================================

Bu paket FOKUS Emlak web sitesinin statik dosyalarını içerir.

KURULUM:
--------

1. Basit HTTP server ile çalıştırma:

   Python 3:
   python3 -m http.server 8000

   Node.js:
   npx http-server -p 8000

2. Tarayıcınızda açın:
   http://localhost:8000

NOT: Dinamik özellikler (veritabanı, API) çalışmaz.
Tam özellikli site için backend bağlantıları gereklidir.

DOSYA YAPISI:
------------
├── index.html          # Ana sayfa
├── listings.html       # İlanlar sayfası
├── listing-detail.html # İlan detay
├── login.html         # Giriş sayfası
├── user-dashboard.html # Kullanıcı paneli
├── assets/            # CSS, JS, resimler
│   ├── css/
│   ├── js/
│   └── images/
├── admin/             # Admin panel
├── sitemap.xml        # SEO sitemap
└── robots.txt         # Robots dosyası

İletişim: info@fokusemlak.com
Web: https://fokusemlak.com
